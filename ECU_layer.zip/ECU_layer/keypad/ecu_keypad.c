#include "ecu_keypad.h"

logic_t click_states = GPIO_LOW;
Std_ReturnType ret;
static const uint8 keypad_values[ECU_KEYPAD_ROWS][ECU_KEYPAD_COLOUMNS] = { {'7','8','9','/'},
                                                                           {'4','5','6','*'},
                                                                           {'1','2','3','-'},
                                                                           {'#','0','=','+'} 
                                                                                              };

Std_ReturnType ecu_keypad_initlaize(keypad_t * keypad){
    Std_ReturnType RET = E_OK;
    uint8 rows_counter = 0;
    uint8 coloumns_counter = 0;

    
    if (NULL == keypad) {
        Std_ReturnType RET = E_NOT_OK;

    }
    else {
        for (rows_counter = 0 ; rows_counter < ECU_KEYPAD_ROWS ; rows_counter++ ) { 
        
        gpio_pin_direction_intialize(&(keypad->keypad_rows[rows_counter]));  
        gpio_pin_write_logic(&(keypad->keypad_rows[rows_counter]), keypad->keypad_rows[rows_counter].logic );

        
       
        }
        
         for (rows_counter = 0 ; coloumns_counter < ECU_KEYPAD_COLOUMNS ; coloumns_counter++ ) {
       
       gpio_pin_direction_intialize(&(keypad->keypad_coloumns[coloumns_counter]));
         }
    
    }
    return RET;
}
Std_ReturnType ecu_keypad_get_value(keypad_t * keypad, uint8 * value){
    
    uint8 row_count = 0;
    uint8 coloumn_count = 0;
    uint8 _count = 0;
    uint32 btn_valid = 0;  
    uint8 value_last_state = 0;  
    uint8 counter = 0;
    
    
    Std_ReturnType RET = E_OK;
    if ( (NULL == keypad) || (NULL == value) ) {
        Std_ReturnType RET = E_NOT_OK;

    }
    else {
        for (row_count = 0 ; row_count < ECU_KEYPAD_ROWS ; row_count++ ) {
                   
            for (_count = 0 ; _count < ECU_KEYPAD_ROWS ; _count++ ) {
                gpio_pin_write_logic(&(keypad->keypad_rows[_count]),GPIO_LOW);
            }
            gpio_pin_write_logic(&(keypad->keypad_rows[row_count]), GPIO_HIGH);
            
            for (coloumn_count = 0 ; coloumn_count < ECU_KEYPAD_COLOUMNS ; coloumn_count++) {
              ret =  gpio_pin_read_logic(&(keypad->keypad_coloumns[coloumn_count]),& click_states);
               if(GPIO_HIGH == click_states) {
                   
                        *value = keypad_values[row_count][coloumn_count]; 
                        
                    }                    
                                         
               }
             
            }
        
       
        }
        
    
    
    return RET;
    }