/* 
 * File:   ecu_keypad.h
 * Author: Omar Hammad
 *
 * Created on 15 July 2025, 14:24
 */

#ifndef ECU_KEYPAD_H
#define	ECU_KEYPAD_H

/*  section : includes */

#include"../../MCAL_layer/GPIO_module/hal_gpio.h"


/*  section : declarations */
#define ECU_KEYPAD_ROWS 4
#define ECU_KEYPAD_COLOUMNS 4
#define VALUE_HIGH GPIO_HIGH
#define VALUE_LOW GPIO_LOW
/*  section : macro functions */

/*  section : data types */
typedef struct {
    pin_config_t keypad_rows[ECU_KEYPAD_ROWS];
    pin_config_t keypad_coloumns[ECU_KEYPAD_COLOUMNS];

}keypad_t;

/*  section : function declarations */

Std_ReturnType ecu_keypad_initlaize(keypad_t * keypad);
Std_ReturnType ecu_keypad_get_value(keypad_t * keypad, uint8 * value);




#endif	/* ECU_KEYPAD_H */

