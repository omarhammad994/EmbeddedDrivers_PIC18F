/* 
 * File:   ecu_led.h
 * Author: Omar Hammad
 *
 * Created on 24 June 2025, 11:08
 */

#ifndef ECU_LED_H
#define	ECU_LED_H
/*  section : includes */
#include"../../MCAL_layer/GPIO_module/hal_gpio.h"

/*  section : declarations */

/*  section : macro functions */

/*  section : data types */

typedef enum {
    LED_OFF,
    LED_ON
}led_status_t;

typedef struct {
  uint8  port_name : 3;
  uint8  pin_index : 3;
  uint8  led_status : 1;
}led_t;


/*  section : function declarations */
Std_ReturnType ecu_led_inialize (const led_t * led);
Std_ReturnType ecu_led_on (const led_t * led);
Std_ReturnType ecu_led_off (const led_t * led);
Std_ReturnType ecu_led_toggle (const led_t * led);






        

#endif	/* ECU_LED_H */

