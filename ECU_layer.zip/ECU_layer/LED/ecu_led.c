#include "ecu_led.h"
 
Std_ReturnType ecu_led_inialize (const led_t * led){
    pin_config_t led_config;
    Std_ReturnType RET = E_OK;
    if (NULL == led){
    
        Std_ReturnType RET = E_NOT_OK;

    }
    else 
    {
    pin_config_t led_config = 
        {
    .port=led->port_name,
    .pin=led->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=led->led_status

        };
    
  RET = gpio_pin_direction_intialize(&led_config);
  RET = gpio_pin_write_logic(&led_config, led->led_status);
    
    }

    return RET;
}

Std_ReturnType ecu_led_on (const led_t * led){
    
    Std_ReturnType RET = E_OK;
    if (NULL == led){
    
        Std_ReturnType RET = E_NOT_OK;

    }
    else {
        pin_config_t led_config = 
        {
    .port=led->port_name,
    .pin=led->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=led->led_status

        };
    
      RET =  gpio_pin_write_logic( &led_config ,GPIO_HIGH);
    }
    

    return RET;

}
Std_ReturnType ecu_led_off (const led_t * led){

    Std_ReturnType RET = E_OK;
    if (NULL == led){
    
        Std_ReturnType RET = E_NOT_OK;

    }
    else {
        pin_config_t led_config = 
        {
    .port=led->port_name,
    .pin=led->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=led->led_status

        };
    
          RET =  gpio_pin_write_logic( &led_config ,GPIO_LOW);

    }
    
    return RET;

}
Std_ReturnType ecu_led_toggle (const led_t * led){

    Std_ReturnType RET = E_OK;
    if (NULL == led){
    
        Std_ReturnType RET = E_NOT_OK;

    }
    else {
        pin_config_t led_config = 
        {
    .port=led->port_name,
    .pin=led->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=led->led_status

        };
    
              RET =  gpio_pin_toggle_logic(&led_config);

    }

    return RET;

}

