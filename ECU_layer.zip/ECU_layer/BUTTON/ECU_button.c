#include "ECU_button.h"

Std_ReturnType ecu_button_initlaize ( button_config_t * button  ){

    Std_ReturnType RET = E_OK;
    if (NULL == button) {
        Std_ReturnType RET = E_NOT_OK;

}
    else {
        gpio_pin_direction_intialize(&(button->button_config));
      
    
         }
    return RET;
}



Std_ReturnType ecu_button_read_state ( button_config_t *button ,button_status_t * button_state ){
    logic_t btn_real_state;
    
    Std_ReturnType RET = E_OK;
    if ((NULL == button) || (NULL == button_state)) {
        Std_ReturnType RET = E_NOT_OK;

}
    else {
    gpio_pin_read_logic(&button->button_config,&btn_real_state);
            if(BUTTON_ACTIVE_HIGH == button->button_active ) {
                if(btn_real_state == GPIO_HIGH) 
                {
                    *button_state = BUTTON_STATUS_PRESSED;
                }
                else {
                        *button_state = BUTTON_STATUS_RELEASED;
                     }
            }
            else if (BUTTON_ACTIVE_LOW == button->button_active ) {
                if (btn_real_state == GPIO_LOW) {
                        *button_state = BUTTON_STATUS_PRESSED;

                }
                else {
                        *button_state = BUTTON_STATUS_RELEASED;                
                     }
            
            }
         }
    return RET;

}
