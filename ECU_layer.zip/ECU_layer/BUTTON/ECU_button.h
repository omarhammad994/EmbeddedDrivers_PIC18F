/* 
 * File:   ECU_button.h
 * Author: Omar Hammad
 *
 * Created on 11 July 2025, 14:56
 */

#ifndef ECU_BUTTON_H
#define	ECU_BUTTON_H

/*  section : includes */
#include"../../MCAL_layer/GPIO_module/hal_gpio.h"
/*  section : declarations */

/*  section : macro functions */

/*  section : data types */
typedef enum {
    BUTTON_STATUS_RELEASED,
    BUTTON_STATUS_PRESSED        
            
}button_status_t;


typedef enum {
    BUTTON_ACTIVE_LOW,
    BUTTON_ACTIVE_HIGH
            
}button_active_t;

typedef struct {
    pin_config_t button_config;
    button_active_t button_active;
    button_status_t button_state;
    
}button_config_t;



/*  section : function declarations */

Std_ReturnType ecu_button_initlaize ( button_config_t * button  );
Std_ReturnType ecu_button_read_state ( button_config_t *button ,button_status_t * button_state );


#endif	/* ECU_BUTTON_H */

