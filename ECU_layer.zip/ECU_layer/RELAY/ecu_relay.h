/* 
 * File:   ecu_relay.h
 * Author: Omar Hammad
 *
 * Created on 12 July 2025, 19:18
 */

#ifndef ECU_RELAY_H
#define	ECU_RELAY_H

/*  section : includes */
#include"../../MCAL_layer/GPIO_module/hal_gpio.h"


/*  section : declarations */

/*  section : macro functions */

/*  section : data types */
typedef enum {
    RELAY_STATE_OFF,
    RELAY_STATE_ON        
}relay_status_t;

typedef struct {
  uint8  port_name : 3;
  uint8  pin_index : 3;
  uint8  relay_status : 1;
}relay_t;

/*  section : function declarations */
Std_ReturnType ecu_relay_initilaize (const relay_t * relay);
Std_ReturnType ecu_relay_turn_on (const relay_t * relay);
Std_ReturnType ecu_relay_turn_off (const relay_t * relay);







#endif	/* ECU_RELAY_H */

