#include "ecu_relay.h"

Std_ReturnType ecu_relay_initilaize (const relay_t * relay){

       Std_ReturnType RET = E_OK;
       if (NULL == relay ) {
              Std_ReturnType RET = E_NOT_OK;
       }
              else
    {
    pin_config_t relay_config = 
        {
    .port=relay->port_name,
    .pin=relay->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=relay->relay_status

        };
    
  RET = gpio_pin_direction_intialize(&relay_config);
  RET = gpio_pin_write_logic(&relay_config, relay->relay_status);
    
    }
       return RET;

}
Std_ReturnType ecu_relay_turn_on (const relay_t * relay){

       Std_ReturnType RET = E_OK;
       if (NULL == relay ) {
              Std_ReturnType RET = E_NOT_OK;

       }
       else {
           pin_config_t relay_config = 
        {
    .port=relay->port_name,
    .pin=relay->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=relay->relay_status

        };
           
           gpio_pin_write_logic(&relay_config ,GPIO_HIGH);
       
       
       
       }

       return RET;

}
Std_ReturnType ecu_relay_turn_off (const relay_t * relay){

       Std_ReturnType RET = E_OK;
       if (NULL == relay ) {
              Std_ReturnType RET = E_NOT_OK;

       }
       else {
           pin_config_t relay_config = 
        {
    .port=relay->port_name,
    .pin=relay->pin_index,
    .direction=GPIO_DIRECTION_OUTPUT,
    .logic=relay->relay_status

        };
           
           gpio_pin_write_logic(&relay_config ,GPIO_LOW);
       
       
       
       }


       return RET;
}
