/* 
 * File:   ecu_seven_segment.h
 * Author: hamma
 *
 * Created on 15 July 2025, 12:48
 */

#ifndef ECU_SEVEN_SEGMENT_H
#define	ECU_SEVEN_SEGMENT_H

/*  section : includes */
#include"../../MCAL_layer/GPIO_module/hal_gpio.h"

/*  section : declarations */

#define SEGMENT_PIN0 0
#define SEGMENT_PIN1 1
#define SEGMENT_PIN2 2
#define SEGMENT_PIN3 3



/*  section : macro functions */

/*  section : data types */

typedef enum {
    segment_common_anode,
    segment_common_cathode
            
}segment_connection_t;

typedef struct {
    pin_config_t segment_pins[4];
    segment_connection_t segment_type;
}segment_t;

/*  section : function declarations */

Std_ReturnType ecu_seven_segment_initlaize(segment_t * segment);
Std_ReturnType ecu_seven_segment_write(segment_t * segment,uint8 number);




#endif	/* ECU_SEVEN_SEGMENT_H */

