#include "ecu_seven_segment.h"

Std_ReturnType ecu_seven_segment_initlaize(segment_t * segment){

    Std_ReturnType RET = E_OK;
    if (NULL == segment){
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        gpio_pin_direction_intialize(&(segment->segment_pins[0]));
        gpio_pin_write_logic( &(segment->segment_pins[0]) , GPIO_LOW );
        gpio_pin_direction_intialize(&(segment->segment_pins[1]));
        gpio_pin_write_logic( &(segment->segment_pins[1]) , GPIO_LOW );
        gpio_pin_direction_intialize(&(segment->segment_pins[2]));
        gpio_pin_write_logic( &(segment->segment_pins[2]) , GPIO_LOW );
        gpio_pin_direction_intialize(&(segment->segment_pins[3]));
        gpio_pin_write_logic( &(segment->segment_pins[3]) , GPIO_LOW );
    
    
    }
    
    return RET;
}
Std_ReturnType ecu_seven_segment_write(segment_t * segment,uint8 number){

    Std_ReturnType RET = E_OK;
    if ((NULL == segment) || (number > 9) ){
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        
        gpio_pin_write_logic( &(segment->segment_pins[SEGMENT_PIN0]) , number&0x01 );
        
        gpio_pin_write_logic( &(segment->segment_pins[SEGMENT_PIN1]) , (number>>1)&0x01 );
       
        gpio_pin_write_logic( &(segment->segment_pins[SEGMENT_PIN2]) , (number>>2)&0x01 );
        
        gpio_pin_write_logic( &(segment->segment_pins[SEGMENT_PIN3]) , (number>>3)&0x01 );

    
    
    }
    
    return RET;


}
