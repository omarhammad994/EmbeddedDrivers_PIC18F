/* 
 * File:   ecu_layer_init.h
 * Author: Omar Hammad
 *
 * Created on 16 July 2025, 10:31
 */

#ifndef ECU_LAYER_INIT_H
#define	ECU_LAYER_INIT_H

/*  section : includes */
#include "BUTTON/ECU_button.h"
#include "DC_motor/ecu_dc_motor.h"
#include "LED/ecu_led.h"
#include "RELAY/ecu_relay.h"
#include "keypad/ecu_keypad.h"
#include "seven_segment/ecu_seven_segment.h"
#include "lcd/chr_lcd.h"
#include <xc.h>


/*  section : declarations */
#define _XTAL_FREQ 4000000


/*  section : macro functions */

/*  section : data types */

/*  section : function declarations */
void ecu_init(void);


#endif	/* ECU_LAYER_INIT_H */

