#include "ecu_dc_motor.h"
static pin_config_t dc_motor_pin1_config;
static pin_config_t dc_motor_pin2_config; 

Std_ReturnType ecu_dc_motor_initalize (const dc_motor_t * dc_motor){
   
    Std_ReturnType RET = E_OK;
    
    if (NULL == dc_motor ) {
           Std_ReturnType RET = E_NOT_OK;
    
    }
    else {
        
        dc_motor_pin1_config.port = dc_motor->dc_motor_pins[0].port_name;
        dc_motor_pin1_config.pin = dc_motor->dc_motor_pins[0].pin_index;
        dc_motor_pin1_config.direction = GPIO_DIRECTION_OUTPUT;
        dc_motor_pin1_config.logic = dc_motor->dc_motor_pins[0].dc_motor_status;        
        
        dc_motor_pin2_config.port = dc_motor->dc_motor_pins[1].port_name;
        dc_motor_pin2_config.pin = dc_motor->dc_motor_pins[1].pin_index;
        dc_motor_pin2_config.direction = GPIO_DIRECTION_OUTPUT;
        dc_motor_pin2_config.logic = dc_motor->dc_motor_pins[1].dc_motor_status;        
        
    
       
       
       gpio_pin_direction_intialize(&dc_motor_pin1_config);
       gpio_pin_direction_intialize(&dc_motor_pin2_config);
       gpio_pin_write_logic(&dc_motor_pin1_config,GPIO_LOW);
       gpio_pin_write_logic(&dc_motor_pin2_config,GPIO_LOW);

       

    
    
    }

   return RET;
}
Std_ReturnType ecu_dc_motor_move_forward (const dc_motor_t * dc_motor){

    Std_ReturnType RET = E_OK;
    
    if (NULL == dc_motor ) {
           Std_ReturnType RET = E_NOT_OK;
    
    }
    else {
        
       
       
       gpio_pin_write_logic(&dc_motor_pin1_config,GPIO_HIGH);
       gpio_pin_write_logic(&dc_motor_pin2_config,GPIO_LOW);
    
    
    
    }

   return RET;

}
Std_ReturnType ecu_dc_motor_move_backward (const dc_motor_t * dc_motor){
    
     Std_ReturnType RET = E_OK;
    
    if (NULL == dc_motor ) {
           Std_ReturnType RET = E_NOT_OK;
    
    }
    else {
        
        
       
       
       
       gpio_pin_write_logic(&dc_motor_pin1_config,GPIO_LOW);
       gpio_pin_write_logic(&dc_motor_pin2_config,GPIO_HIGH);
    
    
    
    }

   return RET;


}
Std_ReturnType ecu_dc_motor_move_stop (const dc_motor_t * dc_motor){
    
     Std_ReturnType RET = E_OK;
    
    if (NULL == dc_motor ) {
           Std_ReturnType RET = E_NOT_OK;
    
    }
    else {
        
       
       
       gpio_pin_write_logic(&dc_motor_pin1_config,GPIO_LOW);
       gpio_pin_write_logic(&dc_motor_pin2_config,GPIO_LOW);
    
    
    
    }

   return RET;



}
