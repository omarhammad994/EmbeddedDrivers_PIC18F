/* 
 * File:   ecu_dc_motor.h
 * Author: Omar Hammad
 *
 * Created on 13 July 2025, 22:27
 */

#ifndef ECU_DC_MOTOR_H
#define	ECU_DC_MOTOR_H
/*  section : includes */
#include"../../MCAL_layer/GPIO_module/hal_gpio.h"

/*  section : declarations */

typedef enum {
    dc_motor_status_off,
    dc_motor_status_on
            
}dc_motor_status_t;

typedef struct {
    uint8 port_name :3;
    uint8 pin_index :3;
    uint8 dc_motor_status :1; 

}dc_motor_pin_t;

typedef struct {
dc_motor_pin_t dc_motor_pins[2];

}dc_motor_t;




/*  section : macro functions */

/*  section : data types */

/*  section : function declarations */

Std_ReturnType ecu_dc_motor_initalize (const dc_motor_t * dc_motor);
Std_ReturnType ecu_dc_motor_move_forward (const dc_motor_t * dc_motor);
Std_ReturnType ecu_dc_motor_move_backward (const dc_motor_t * dc_motor);
Std_ReturnType ecu_dc_motor_move_stop (const dc_motor_t * dc_motor);






#endif	/* ECU_DC_MOTOR_H */

