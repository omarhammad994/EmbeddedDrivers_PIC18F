#include "ecu_layer_init.h"


chr_lcd_4bit lcd1 = {
.res.port = PORTC_INDEX,
.res.pin = PIN0,
.res.direction = GPIO_DIRECTION_OUTPUT,
.res.logic = GPIO_LOW,
.en.port = PORTC_INDEX,
.en.pin = PIN1,
.en.direction = GPIO_DIRECTION_OUTPUT,
.en.logic = GPIO_LOW,
.data[0].port = PORTC_INDEX,
.data[0].pin = PIN2,
.data[0].direction = GPIO_DIRECTION_OUTPUT,
.data[0].logic = GPIO_LOW,
.data[1].port = PORTC_INDEX,
.data[1].pin = PIN3,
.data[1].direction = GPIO_DIRECTION_OUTPUT,
.data[1].logic = GPIO_LOW,
.data[2].port = PORTC_INDEX,
.data[2].pin = PIN4,
.data[2].direction = GPIO_DIRECTION_OUTPUT,
.data[2].logic = GPIO_LOW,
.data[3].port = PORTC_INDEX,
.data[3].pin = PIN5,
.data[3].direction = GPIO_DIRECTION_OUTPUT,
.data[3].logic = GPIO_LOW,

};

keypad_t keypad ={
.keypad_rows[0].port = PORTD_INDEX,
.keypad_rows[0].pin = PIN0,
.keypad_rows[0].direction = GPIO_DIRECTION_OUTPUT,
.keypad_rows[0].logic = GPIO_LOW,
.keypad_rows[1].port = PORTD_INDEX,
.keypad_rows[1].pin = PIN1,
.keypad_rows[1].direction = GPIO_DIRECTION_OUTPUT,
.keypad_rows[1].logic = GPIO_LOW,
.keypad_rows[2].port = PORTD_INDEX,
.keypad_rows[2].pin = PIN2,
.keypad_rows[2].direction = GPIO_DIRECTION_OUTPUT,
.keypad_rows[2].logic = GPIO_LOW,
.keypad_rows[3].port = PORTD_INDEX,
.keypad_rows[3].pin = PIN3,
.keypad_rows[3].direction = GPIO_DIRECTION_OUTPUT,
.keypad_rows[3].logic = GPIO_LOW,

.keypad_coloumns[0].port = PORTD_INDEX,
.keypad_coloumns[0].pin = PIN4,
.keypad_coloumns[0].direction = GPIO_DIRECTION_INPUT,
.keypad_coloumns[0].logic = GPIO_LOW,
.keypad_coloumns[1].port = PORTD_INDEX,
.keypad_coloumns[1].pin = PIN5,
.keypad_coloumns[1].direction = GPIO_DIRECTION_INPUT,
.keypad_coloumns[1].logic = GPIO_LOW,
.keypad_coloumns[2].port = PORTD_INDEX,
.keypad_coloumns[2].pin = PIN6,
.keypad_coloumns[2].direction = GPIO_DIRECTION_INPUT,
.keypad_coloumns[2].logic = GPIO_LOW,
.keypad_coloumns[3].port = PORTD_INDEX,
.keypad_coloumns[3].pin = PIN7,
.keypad_coloumns[3].direction = GPIO_DIRECTION_INPUT,
.keypad_coloumns[3].logic = GPIO_LOW


};

led_t led_red1 ={
.port_name=PORTC_INDEX,
.pin_index=PIN6,
.led_status=LED_OFF

};

led_t led_gre1 ={
.port_name=PORTC_INDEX,
.pin_index=PIN7,
.led_status=LED_OFF

};

dc_motor_t dc_motor1 = {
.dc_motor_pins[0].port_name = PORTA_INDEX,
.dc_motor_pins[0].pin_index = PIN0,
.dc_motor_pins[0].dc_motor_status = dc_motor_status_off,
.dc_motor_pins[1].port_name = PORTA_INDEX,
.dc_motor_pins[1].pin_index = PIN1,
.dc_motor_pins[1].dc_motor_status = dc_motor_status_off

};

relay_t motor_relay = {
    
.port_name = PORTB_INDEX,
.pin_index = PIN0,
.relay_status = RELAY_STATE_OFF



};




void ecu_init(void) {
 lcd_4bit_initilaize(&lcd1);
 ecu_keypad_initlaize(&keypad);
 ecu_led_inialize(&led_red1);
 ecu_led_inialize(&led_gre1);
 ecu_relay_initilaize(&motor_relay);

 
}