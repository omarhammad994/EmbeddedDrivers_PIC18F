/* 
 * File:   chr_lcd.h
 * Author: Omar Hammad
 *
 * Created on 16 July 2025, 22:58
 */

#ifndef CHR_LCD_H
#define	CHR_LCD_H

/*  section : includes */
#include "../../MCAL_layer/GPIO_module/hal_gpio.h"

/*  section : declarations */
#define LCD_CLEAR_DISPLAY                  0x01
#define LCD_RETURN_HOME                    0x02
#define LCD_ENTRY_MODE_DEC_SHIFT_OFF       0x04
#define LCD_ENTRY_MODE_DEC_SHIFT_ON        0x05
#define LCD_ENTRY_MODE_INC_SHIFT_OFF       0x06
#define LCD_ENTRY_MODE_INC_SHIFT_ON        0x07
#define LCD_CURSOR_MOVE_SHIFT_LEFT         0x10
#define LCD_CURSOR_MOVE_SHIFT_RIGHT        0X14
#define LCD_DISPALY_SHIFT_LEFT             0x18
#define LCD_DISPALY_SHIFT_RIGHT            0x1C
#define LCD_DISPLAY_ON_CURSOR_ON_UNDERLINE_ON  0x0F
#define LCD_DISPLAY_ON_CURSOR_ON_UNDERLINE_OFF 0x0D
#define LCD_DISPLAY_ON_CURSOR_OFF_UNDERLINE_ON 0x0E
#define LCD_DISPLAY_ON_CURSOR_OFF_UNDERLINE_OFF 0x0C
#define LCD_DISPLAY_OFF   0x08
#define LCD_4BIT_MODE_2_LINE    0x28
#define LCD_8BIT_MODE_2_LINE    0x38

#define LCD_CGRAM_START 0x40
#define LCD_DDRAM_START 0x80

#define ROW1 1
#define ROW2 2
#define ROW3 3
#define ROW4 4





/*  section : macro functions */

/*  section : data types */
typedef struct {
    pin_config_t res;
    pin_config_t en;
    pin_config_t data[4];

}chr_lcd_4bit;

typedef struct {
    pin_config_t res;
    pin_config_t en;
    pin_config_t data[8];

}chr_lcd_8bit;

/*  section : function declarations */

Std_ReturnType lcd_4bit_initilaize(const chr_lcd_4bit * lcd);
Std_ReturnType lcd_4bit_send_command(const chr_lcd_4bit * lcd,uint8 command);
Std_ReturnType lcd_4bit_send_char_data(const chr_lcd_4bit * lcd , uint8 data);
Std_ReturnType lcd_4bit_send_char_data_pos(const chr_lcd_4bit * lcd , uint8 data , uint8 row , uint8 coloumn);
Std_ReturnType lcd_4bit_send_string_data(const chr_lcd_4bit * lcd , uint8 *str);
Std_ReturnType lcd_4bit_send_string_data_pos(const chr_lcd_4bit * lcd , uint8 * str , uint8 row , uint8 coloumn);
Std_ReturnType lcd_4bit_send_custom_charachter(const chr_lcd_4bit * lcd , uint8 row , uint8 coloumn , const uint8 chr[], uint8 mem_pos);

Std_ReturnType lcd_8bit_initilaize(const chr_lcd_8bit * lcd);
Std_ReturnType lcd_8bit_send_command(const chr_lcd_8bit * lcd,uint8 command);
Std_ReturnType lcd_8bit_send_char_data(const chr_lcd_8bit * lcd , uint8 data);
Std_ReturnType lcd_8bit_send_char_data_pos(const chr_lcd_8bit * lcd , uint8 data , uint8 row , uint8 coloumn);
Std_ReturnType lcd_8bit_send_string_data(const chr_lcd_8bit * lcd , uint8 *str);
Std_ReturnType lcd_8bit_send_string_data_pos(const chr_lcd_8bit * lcd , uint8 * str , uint8 row , uint8 coloumn);
Std_ReturnType lcd_8bit_send_custom_charachter(const chr_lcd_8bit * lcd , uint8 row , uint8 coloumn , const uint8 chr[], uint8 mem_pos);


void convert_uint8_to_string (uint8 value, uint8 *str);
void convert_uint16_to_string (uint16 value, uint16 *str);
void convert_uint32_to_string (uint32 value, uint32 *str);






#endif	/* CHR_LCD_H */

