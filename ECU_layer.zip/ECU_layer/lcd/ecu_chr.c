#include "chr_lcd.h"
static void lcd_send_4bit (const chr_lcd_4bit * lcd,uint8 command1 );
static void lcd_send_enable (const chr_lcd_4bit * lcd);
static void lcd_8bit_set_cursor (const chr_lcd_8bit * lcd, uint8 row, uint8 coloumn);
static void lcd_4bit_set_cursor (const chr_lcd_4bit * lcd, uint8 row, uint8 coloumn);

Std_ReturnType lcd_4bit_initilaize(const chr_lcd_4bit * lcd){
Std_ReturnType RET = E_OK;
uint8 lcd_counter = 0;
    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    
    gpio_pin_direction_intialize(&(lcd->res));
    gpio_pin_write_logic(&(lcd->res),lcd->res.logic);
    
    gpio_pin_direction_intialize(&(lcd->en));
    gpio_pin_write_logic(&(lcd->en),lcd->en.logic);
    
    for (lcd_counter = 0 ; lcd_counter < 4 ; lcd_counter++) {
        gpio_pin_direction_intialize(&(lcd->data[lcd_counter]));
        gpio_pin_write_logic(&(lcd->data[lcd_counter]),lcd->data[lcd_counter].logic);
    
    }
    __delay_ms(20);
    lcd_4bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    __delay_ms(5);
    lcd_4bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    __delay_us(150);
    lcd_4bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    lcd_4bit_send_command(lcd,LCD_CLEAR_DISPLAY);
    lcd_4bit_send_command(lcd,LCD_RETURN_HOME);
    lcd_4bit_send_command(lcd,LCD_DISPLAY_ON_CURSOR_ON_UNDERLINE_OFF);
    lcd_4bit_send_command(lcd,LCD_4BIT_MODE_2_LINE);
    lcd_4bit_send_command(lcd,LCD_DDRAM_START);
    lcd_4bit_send_command(lcd,LCD_DISPLAY_ON_CURSOR_ON_UNDERLINE_OFF);

    
    
    
    
    }

    return RET;
}
Std_ReturnType lcd_4bit_send_command(const chr_lcd_4bit * lcd,uint8 command){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
            gpio_pin_write_logic(&(lcd->res),GPIO_LOW);
            
            lcd_send_4bit(lcd,command >> 4);
            lcd_send_enable(lcd);
            lcd_send_4bit(lcd,command);
            lcd_send_enable(lcd);
        
        
    }

    return RET;
}
Std_ReturnType lcd_4bit_send_char_data(const chr_lcd_4bit * lcd , uint8 data){
    Std_ReturnType RET = E_OK;

if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    gpio_pin_write_logic(&(lcd->res),GPIO_HIGH);
            
            lcd_send_4bit(lcd,(data>>4));
            lcd_send_enable(lcd);
            lcd_send_4bit(lcd,data);
            lcd_send_enable(lcd);
    
    }

    return RET;
}
Std_ReturnType lcd_4bit_send_char_data_pos(const chr_lcd_4bit * lcd , uint8 data , uint8 row , uint8 coloumn){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        lcd_4bit_set_cursor(lcd,row,coloumn);
        lcd_4bit_send_char_data(lcd,data);
        
    
    }

    return RET;
}
Std_ReturnType lcd_4bit_send_string_data(const chr_lcd_4bit * lcd , uint8 *str){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    while (*str) {
            lcd_4bit_send_char_data(lcd,*str++);
        }
    
    }

    return RET;
}
Std_ReturnType lcd_4bit_send_string_data_pos(const chr_lcd_4bit * lcd , uint8 * str , uint8 row , uint8 coloumn){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        lcd_4bit_set_cursor(lcd,row,coloumn);
        
        while (*str) {
            lcd_4bit_send_char_data(lcd,*str++);
             }
    
    }

    return RET;
}
Std_ReturnType lcd_4bit_send_custom_charachter(const chr_lcd_4bit * lcd , uint8 row , uint8 coloumn , const uint8 chr[], uint8 mem_pos){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    
    
    }

    return RET;
}

Std_ReturnType lcd_8bit_initilaize(const chr_lcd_8bit * lcd){
Std_ReturnType RET = E_OK;
uint8 lcd_counter = 0;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    gpio_pin_direction_intialize(&(lcd->res));
    gpio_pin_write_logic(&(lcd->res),lcd->res.logic);
    
    gpio_pin_direction_intialize(&(lcd->en));
    gpio_pin_write_logic(&(lcd->en),lcd->en.logic);
    
    for (lcd_counter = 0 ; lcd_counter > 8 ; lcd_counter++) {
        gpio_pin_direction_intialize(&(lcd->data[lcd_counter]));
        gpio_pin_write_logic(&(lcd->data[lcd_counter]),lcd->data[lcd_counter].logic);
    
    }
    
    __delay_ms(20);
    lcd_8bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    __delay_ms(5);
    lcd_8bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    __delay_us(150);
    lcd_8bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    lcd_8bit_send_command(lcd,LCD_CLEAR_DISPLAY);
    lcd_8bit_send_command(lcd,LCD_RETURN_HOME);
    lcd_8bit_send_command(lcd,LCD_DISPLAY_ON_CURSOR_OFF_UNDERLINE_OFF);
    lcd_8bit_send_command(lcd,LCD_8BIT_MODE_2_LINE);
    lcd_8bit_send_command(lcd,LCD_DDRAM_START);


    }

    return RET;
}
Std_ReturnType lcd_8bit_send_command(const chr_lcd_8bit * lcd,uint8 command){
Std_ReturnType RET = E_OK;
uint8 lcd_counter = 0;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        gpio_pin_write_logic(&(lcd->res),GPIO_LOW);
        
        for (lcd_counter = 0 ; lcd_counter < 8 ; lcd_counter++){
            gpio_pin_write_logic(&(lcd->data[lcd_counter]),(command>>lcd_counter&0x01));
        }
    
    
    }

    return RET;
}
Std_ReturnType lcd_8bit_send_char_data(const chr_lcd_8bit * lcd , uint8 data){
Std_ReturnType RET = E_OK;
uint8 lcd_counter = 0;


    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    gpio_pin_write_logic(&(lcd->res),GPIO_HIGH);
        
        for (lcd_counter = 0 ; lcd_counter < 8 ; lcd_counter++){
            gpio_pin_write_logic(&(lcd->data[lcd_counter]),(data>>lcd_counter&0x01));
    
    }

    return RET;
    }
}

Std_ReturnType lcd_8bit_send_char_data_pos(const chr_lcd_8bit * lcd , uint8 data , uint8 row , uint8 coloumn){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    lcd_8bit_set_cursor(lcd,row,coloumn);
    lcd_8bit_send_char_data(lcd,data);
    
    }

    return RET;
}
Std_ReturnType lcd_8bit_send_string_data(const chr_lcd_8bit * lcd , uint8 *str){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        while (*str) {
            lcd_8bit_send_char_data(lcd,*str++);
        }
    
    }

    return RET;
}
Std_ReturnType lcd_8bit_send_string_data_pos(const chr_lcd_8bit * lcd , uint8 * str , uint8 row , uint8 coloumn){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
        lcd_8bit_set_cursor(lcd,row,coloumn);
        while (*str) {
            lcd_8bit_send_char_data(lcd,*str++);
            }

    
    }

    return RET;
}
Std_ReturnType lcd_8bit_send_custom_charachter(const chr_lcd_8bit * lcd , uint8 row , uint8 coloumn , const uint8 chr[], uint8 mem_pos){
Std_ReturnType RET = E_OK;

    if (NULL == lcd) {
        Std_ReturnType RET = E_NOT_OK;
    }
    else {
    
    
    }

    return RET;
}

void convert_uint8_to_string (uint8 value, uint8 *str){

    memset(str,'\0',4);
    sprintf(str, "%i",value);
}
void convert_uint16_to_string (uint16 value, uint16 *str){
 memset(str,'\0',6);
    sprintf(str, "%i",value);
}


void convert_uint32_to_string (uint32 value, uint32 *str){

 memset(str,'\0',11);
    sprintf(str, "%i",value);
}









static void lcd_send_4bit (const chr_lcd_4bit * lcd,uint8 command1 ) {

            gpio_pin_write_logic(&(lcd->data[0]), (command1 >> 0) & (uint8) 0x01);
            gpio_pin_write_logic(&(lcd->data[1]), (command1 >> 1) & (uint8) 0x01);
            gpio_pin_write_logic(&(lcd->data[2]), (command1 >> 2) & (uint8) 0x01);
            gpio_pin_write_logic(&(lcd->data[3]), (command1 >> 3) & (uint8) 0x01);


}

static void lcd_send_enable (const chr_lcd_4bit * lcd) {
    gpio_pin_write_logic(&(lcd->en),GPIO_HIGH);
    __delay_us(5);
    gpio_pin_write_logic(&(lcd->en),GPIO_LOW);


}

static void lcd_8bit_set_cursor (const chr_lcd_8bit * lcd, uint8 row, uint8 coloumn){
coloumn--;
    switch (row) {
        case ROW1 : lcd_8bit_send_command (lcd, (0x80+coloumn)); break;
        case ROW2 : lcd_8bit_send_command (lcd, (0xC0+coloumn)); break;
        case ROW3 : lcd_8bit_send_command (lcd, (0x94+coloumn)); break;
        case ROW4 : lcd_8bit_send_command (lcd, (0xd4+coloumn)); break;
        default : ;
    
    
    }


}

static void lcd_4bit_set_cursor (const chr_lcd_4bit * lcd, uint8 row, uint8 coloumn){
coloumn--;
    switch (row) {
        case ROW1 : lcd_4bit_send_command (lcd, (0x80+coloumn)); break;
        case ROW2 : lcd_4bit_send_command (lcd, (0xC0+coloumn)); break;
        case ROW3 : lcd_4bit_send_command (lcd, (0x94+coloumn)); break;
        case ROW4 : lcd_4bit_send_command (lcd, (0xd4+coloumn)); break;
        default : ;
    
    
    }


}