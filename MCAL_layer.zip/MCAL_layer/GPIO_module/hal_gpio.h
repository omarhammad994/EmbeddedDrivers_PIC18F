/* 
 * File:   hal_gpio.h
 * Author: Omar Hammad
 *
 * Created on 24 June 2025, 10:24
 */

/*  section : includes */
#ifndef HAL_GPIO_H
#define	HAL_GPIO_H
#include "pic18f4620.h"
#include "../../MCAL_layer/mcal_std_types.h"
#include "../../MCAL_layer/device_config.h"
#include "pic18f4620.h"
#include <xc.h>



/*  section : declarations */

#define BIT_MASK        (uint8)1
#define PIN_MAX_NUMBER         8
#define PORT_MAX_NUMBER        5
#define PORT_MASK              0xFF
#define _XTAL_FREQ 4000000


/*  section : macro functions */

#define HWREG(_x) (*((volatile uint8 *)(_x)))

#define SET_BIT(REG,BIT_POSN)  (REG |=  (BIT_MASK <<  BIT_POSN))
#define CLEAR_BIT(REG,BIT_POSN)  (REG &= ~(BIT_MASK <<  BIT_POSN))
#define TOGGLE_BIT(REG,BIT_POSN)  (REG ^=  (BIT_MASK <<  BIT_POSN))
#define READ_BIT(REG,BIT_POSN)  (REG >> BIT_POSN) & BIT_MASK


/*  section : data types */

typedef enum{
    GPIO_LOW,
    GPIO_HIGH       

}logic_t;

typedef enum{
    GPIO_DIRECTION_OUTPUT,
    GPIO_DIRECTION_INPUT       

}direction_t;

typedef enum{
    PIN0,
    PIN1,
    PIN2,
    PIN3,
    PIN4,        
    PIN5,
    PIN6,        
    PIN7        
           
}pin_t;


typedef enum{
    PORTA_INDEX,
    PORTB_INDEX,
    PORTC_INDEX,
    PORTD_INDEX,
    PORTE_INDEX        
      
}port_t;

typedef struct {
   uint8 port :3;       /*@ref port_t  */
   uint8 pin  :3;       /*@ref pin_t  */
   uint8 direction :1;  /*@ref direction_t */
   uint8 logic :1;      /*@ref logic_t */
   
}pin_config_t;

/*  section : function declarations */

Std_ReturnType gpio_pin_direction_intialize (const pin_config_t * pin_config);
Std_ReturnType gpio_pin_get_direction_status (const pin_config_t * pin_config , direction_t * direction_status);  
Std_ReturnType gpio_pin_write_logic (const pin_config_t * pin_config , logic_t logic );
Std_ReturnType gpio_pin_read_logic (const pin_config_t * pin_config , logic_t * logic );
Std_ReturnType gpio_pin_toggle_logic (const pin_config_t * pin_config);

Std_ReturnType gpio_port_direction_intialize ( port_t  port , uint8 direction);
Std_ReturnType gpio_port_get_direction_status ( port_t  port , uint8 * direction_status );
Std_ReturnType gpio_port_write_logic ( port_t  port , uint8 logic );
Std_ReturnType gpio_port_read_logic ( port_t  port , uint8 * logic );
Std_ReturnType gpio_port_toggle_logic ( port_t  port);











#endif	/* HAL_GPIO_H */

