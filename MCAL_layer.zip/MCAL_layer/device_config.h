/* 
 * File:   device_config.h
 * Author: Omar Hammad
 *
 * Created on 24 June 2025, 11:02
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H



#endif	/* DEVICE_CONFIG_H */

