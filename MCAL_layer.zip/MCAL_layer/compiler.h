/* 
 * File:   compiler.h
 * Author: Omar Hammad
 *
 * Created on 24 June 2025, 11:05
 */

#ifndef COMPILER_H
#define	COMPILER_H

#include <xc.h>


#endif	/* COMPILER_H */

