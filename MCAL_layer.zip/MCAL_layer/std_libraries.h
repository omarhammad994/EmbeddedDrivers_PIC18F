/* 
 * File:   std_libraries.h
 * Author: Omar Hammad
 *
 * Created on 24 June 2025, 11:05
 */

#ifndef STD_LIBRARIES_H
#define	STD_LIBRARIES_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* STD_LIBRARIES_H */

